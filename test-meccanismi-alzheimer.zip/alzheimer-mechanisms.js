(() => {
  const TARGET_ID = "alzheimers-disease";
  const STYLE_ID = "kr-alzheimer-mechanisms-style";
  const BLOCK_ID = "kr-alzheimer-mechanisms";

  const CSS = `
  #${BLOCK_ID}{
    margin:14px 0 22px;
    border:1px solid #d6e1ea;
    border-radius:14px;
    background:#f8fbfe;
    overflow:hidden;
  }
  #${BLOCK_ID} .kr-mech-head{
    padding:16px 18px 13px;
    border-bottom:1px solid #dfe8ef;
    background:#fff;
  }
  #${BLOCK_ID} .kr-mech-eyebrow{
    display:block;
    margin-bottom:4px;
    font-size:9px;
    line-height:1.2;
    font-weight:700;
    letter-spacing:.14em;
    text-transform:uppercase;
    color:#2b6ca3;
  }
  #${BLOCK_ID} h3{
    margin:0 0 6px;
    font-size:19px;
    line-height:1.25;
    color:#17324d;
  }
  #${BLOCK_ID} .kr-mech-intro{
    margin:0;
    max-width:900px;
    font-size:13px;
    line-height:1.55;
    color:#526a7d;
  }
  #${BLOCK_ID} .kr-mech-list{
    display:grid;
    grid-template-columns:1fr;
  }
  #${BLOCK_ID} .kr-mech-row{
    display:grid;
    grid-template-columns:minmax(0,1fr) auto;
    gap:14px;
    align-items:start;
    padding:13px 18px;
    border-bottom:1px solid #e1e9f0;
  }
  #${BLOCK_ID} .kr-mech-row:last-child{
    border-bottom:0;
  }
  #${BLOCK_ID} .kr-mech-title{
    display:block;
    margin-bottom:3px;
    font-size:13px;
    line-height:1.3;
    font-weight:700;
    color:#17324d;
  }
  #${BLOCK_ID} .kr-mech-text{
    margin:0;
    font-size:12px;
    line-height:1.5;
    color:#5b7184;
  }
  #${BLOCK_ID} .kr-mech-level{
    display:inline-flex;
    align-items:center;
    min-height:25px;
    padding:4px 8px;
    border-radius:999px;
    border:1px solid #cbdbe8;
    background:#fff;
    color:#315b7e;
    font-size:9px;
    line-height:1.15;
    font-weight:700;
    white-space:nowrap;
  }
  #${BLOCK_ID} .kr-mech-level.human{
    background:#edf7f0;
    border-color:#cfe5d5;
    color:#326846;
  }
  #${BLOCK_ID} .kr-mech-level.preclinical{
    background:#eef5fb;
    border-color:#d2e2ef;
    color:#285f8d;
  }
  #${BLOCK_ID} .kr-mech-level.proposed{
    background:#f7f2fb;
    border-color:#e4d8ef;
    color:#6a4a82;
  }
  #${BLOCK_ID} .kr-mech-footer{
    display:flex;
    flex-wrap:wrap;
    justify-content:space-between;
    gap:10px 18px;
    align-items:center;
    padding:11px 18px 13px;
    border-top:1px solid #dfe8ef;
    background:#fff;
  }
  #${BLOCK_ID} .kr-mech-note{
    margin:0;
    font-size:10px;
    line-height:1.45;
    color:#6b7f90;
  }
  #${BLOCK_ID} .kr-mech-sources{
    display:flex;
    flex-wrap:wrap;
    gap:6px;
  }
  #${BLOCK_ID} .kr-mech-sources a{
    display:inline-flex;
    padding:5px 8px;
    border:1px solid #d4e3ef;
    border-radius:6px;
    background:#eef5fb;
    color:#1f4e79;
    font-size:9px;
    line-height:1.2;
    font-weight:700;
    text-decoration:none;
  }
  #${BLOCK_ID} .kr-mech-sources a:hover{
    border-color:#9ebbd2;
    background:#e6f0f8;
  }
  @media(max-width:680px){
    #${BLOCK_ID}{margin:12px 0 18px;border-radius:12px}
    #${BLOCK_ID} .kr-mech-head{padding:14px}
    #${BLOCK_ID} h3{font-size:17px}
    #${BLOCK_ID} .kr-mech-row{
      grid-template-columns:1fr;
      gap:8px;
      padding:12px 14px;
    }
    #${BLOCK_ID} .kr-mech-level{
      justify-self:start;
    }
    #${BLOCK_ID} .kr-mech-footer{
      padding:10px 14px 12px;
    }
  }`;

  const HTML = `
  <section id="${BLOCK_ID}" aria-labelledby="kr-alzheimer-mechanisms-title">
    <div class="kr-mech-head">
      <span class="kr-mech-eyebrow"
        data-en="Mechanistic rationale"
        data-it="Razionale meccanicistico">Mechanistic rationale</span>
      <h3 id="kr-alzheimer-mechanisms-title"
        data-en="Biological rationale and proposed mechanisms"
        data-it="Razionale biologico e meccanismi proposti">Biological rationale and proposed mechanisms</h3>
      <p class="kr-mech-intro"
        data-en="Why it is being studied: cerebral glucose utilization is impaired early in Alzheimer’s disease, while the capacity to use ketone bodies appears relatively preserved. Ketogenic interventions are therefore investigated both as an alternative fuel strategy and for possible signaling effects."
        data-it="Perché viene studiata: nell’Alzheimer l’utilizzazione cerebrale del glucosio è compromessa precocemente, mentre la capacità di utilizzare i corpi chetonici appare relativamente preservata. Gli interventi chetogenici vengono quindi studiati sia come strategia di substrato energetico alternativo sia per possibili effetti di segnalazione.">Why it is being studied: cerebral glucose utilization is impaired early in Alzheimer’s disease, while the capacity to use ketone bodies appears relatively preserved.</p>
    </div>

    <div class="kr-mech-list">
      <div class="kr-mech-row">
        <div>
          <span class="kr-mech-title"
            data-en="Alternative cerebral energy substrate"
            data-it="Substrato energetico cerebrale alternativo">Alternative cerebral energy substrate</span>
          <p class="kr-mech-text"
            data-en="Human PET studies indicate that cerebral ketone uptake remains responsive to circulating ketones and can increase total brain energy supply without restoring glucose utilization."
            data-it="Studi PET nell’uomo indicano che l’uptake cerebrale dei chetoni rimane responsivo alla loro concentrazione circolante e può aumentare l’apporto energetico cerebrale senza ripristinare l’utilizzazione del glucosio.">Human PET studies indicate that cerebral ketone uptake remains responsive to circulating ketones.</p>
        </div>
        <span class="kr-mech-level human"
          data-en="Human evidence"
          data-it="Evidenza nell’uomo">Human evidence</span>
      </div>

      <div class="kr-mech-row">
        <div>
          <span class="kr-mech-title"
            data-en="Mitochondrial bioenergetics"
            data-it="Bioenergetica mitocondriale">Mitochondrial bioenergetics</span>
          <p class="kr-mech-text"
            data-en="Ketosis and β-hydroxybutyrate may influence mitochondrial respiration, redox balance and ATP production. Most causal evidence for these pathways remains preclinical."
            data-it="Chetosi e β-idrossibutirrato possono influenzare respirazione mitocondriale, equilibrio redox e produzione di ATP. La maggior parte delle evidenze causali su queste vie resta preclinica.">Ketosis and β-hydroxybutyrate may influence mitochondrial respiration, redox balance and ATP production.</p>
        </div>
        <span class="kr-mech-level preclinical"
          data-en="Preclinical"
          data-it="Preclinico">Preclinical</span>
      </div>

      <div class="kr-mech-row">
        <div>
          <span class="kr-mech-title"
            data-en="Neuroinflammation and NLRP3"
            data-it="Neuroinfiammazione e NLRP3">Neuroinflammation and NLRP3</span>
          <p class="kr-mech-text"
            data-en="β-Hydroxybutyrate has been associated with reduced NLRP3 inflammasome activation and altered microglial inflammatory signaling. Translation of this mechanism to clinical Alzheimer outcomes is not established."
            data-it="Il β-idrossibutirrato è stato associato a una riduzione dell’attivazione dell’inflammasoma NLRP3 e a modificazioni della segnalazione infiammatoria microgliale. La traduzione di questo meccanismo in esiti clinici nell’Alzheimer non è ancora dimostrata.">β-Hydroxybutyrate has been associated with reduced NLRP3 inflammasome activation.</p>
        </div>
        <span class="kr-mech-level preclinical"
          data-en="Mainly preclinical"
          data-it="Prevalentemente preclinico">Mainly preclinical</span>
      </div>

      <div class="kr-mech-row">
        <div>
          <span class="kr-mech-title"
            data-en="Oxidative stress and redox signaling"
            data-it="Stress ossidativo e segnalazione redox">Oxidative stress and redox signaling</span>
          <p class="kr-mech-text"
            data-en="Proposed pathways include modulation of ROS production, endogenous antioxidant defenses, NAD⁺/NADH balance and related signaling. Direct clinical confirmation in Alzheimer’s disease remains limited."
            data-it="Le vie proposte comprendono modulazione della produzione di ROS, difese antiossidanti endogene, equilibrio NAD⁺/NADH e relativa segnalazione. La conferma clinica diretta nell’Alzheimer resta limitata.">Proposed pathways include modulation of ROS production and endogenous antioxidant defenses.</p>
        </div>
        <span class="kr-mech-level preclinical"
          data-en="Preclinical"
          data-it="Preclinico">Preclinical</span>
      </div>

      <div class="kr-mech-row">
        <div>
          <span class="kr-mech-title"
            data-en="Amyloid, tau and neuronal signaling"
            data-it="Amiloide, tau e segnalazione neuronale">Amyloid, tau and neuronal signaling</span>
          <p class="kr-mech-text"
            data-en="Changes in amyloid-β, tau-related biology, synaptic signaling and neurotrophic pathways have been reported, but much of the mechanistic evidence derives from animal models or small human studies."
            data-it="Sono state descritte modificazioni della biologia di amiloide-β e tau, della segnalazione sinaptica e di vie neurotrofiche, ma gran parte dell’evidenza meccanicistica deriva da modelli animali o piccoli studi nell’uomo.">Changes in amyloid-β, tau-related biology and synaptic signaling have been reported.</p>
        </div>
        <span class="kr-mech-level proposed"
          data-en="Proposed / translational"
          data-it="Proposto / traslazionale">Proposed / translational</span>
      </div>
    </div>

    <div class="kr-mech-footer">
      <p class="kr-mech-note"
        data-en="The labels describe the level of support for the mechanism, not the overall clinical efficacy of ketogenic therapy in Alzheimer’s disease."
        data-it="Le etichette descrivono il livello di supporto del meccanismo, non l’efficacia clinica complessiva della terapia chetogenica nell’Alzheimer.">The labels describe the level of support for the mechanism, not overall clinical efficacy.</p>
      <div class="kr-mech-sources" aria-label="Key references">
        <a href="https://pubmed.ncbi.nlm.nih.gov/29914035/" target="_blank" rel="noopener">PMID 29914035</a>
        <a href="https://pubmed.ncbi.nlm.nih.gov/31757576/" target="_blank" rel="noopener">PMID 31757576</a>
        <a href="https://pubmed.ncbi.nlm.nih.gov/38989642/" target="_blank" rel="noopener">PMID 38989642</a>
        <a href="https://pubmed.ncbi.nlm.nih.gov/38360180/" target="_blank" rel="noopener">PMID 38360180</a>
      </div>
    </div>
  </section>`;

  function detectLanguage() {
    const htmlLang = (document.documentElement.lang || "").toLowerCase();
    if (htmlLang.startsWith("it")) return "it";

    const active = [...document.querySelectorAll(".lang button, [data-lang]")]
      .find(el => el.classList.contains("active") || el.getAttribute("aria-pressed") === "true");
    if (active) {
      const token = (
        active.dataset.lang ||
        active.textContent ||
        ""
      ).trim().toLowerCase();
      if (token === "it" || token.includes("ital")) return "it";
    }

    const stored = (
      localStorage.getItem("kr-lang") ||
      localStorage.getItem("language") ||
      localStorage.getItem("lang") ||
      ""
    ).toLowerCase();
    if (stored.startsWith("it")) return "it";

    return "en";
  }

  function applyLanguage(root = document) {
    const lang = detectLanguage();
    root.querySelectorAll("[data-en][data-it]").forEach(el => {
      el.innerHTML = el.dataset[lang];
    });
  }

  function install() {
    if (document.getElementById(BLOCK_ID)) return;

    const target = document.getElementById(TARGET_ID);
    if (!target) return;

    const body = target.querySelector(".folder-body");
    if (!body) return;

    if (!document.getElementById(STYLE_ID)) {
      const style = document.createElement("style");
      style.id = STYLE_ID;
      style.textContent = CSS;
      document.head.appendChild(style);
    }

    const holder = document.createElement("div");
    holder.innerHTML = HTML.trim();
    const block = holder.firstElementChild;

    const intro = body.querySelector(":scope > p");
    if (intro) {
      intro.insertAdjacentElement("afterend", block);
    } else {
      body.prepend(block);
    }

    applyLanguage(block);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", install, { once: true });
  } else {
    install();
  }

  document.addEventListener("click", event => {
    if (event.target.closest(".lang button, [data-lang]")) {
      setTimeout(() => {
        const block = document.getElementById(BLOCK_ID);
        if (block) applyLanguage(block);
      }, 0);
    }
  });

  const observer = new MutationObserver(() => {
    const block = document.getElementById(BLOCK_ID);
    if (block) applyLanguage(block);
  });
  observer.observe(document.documentElement, {
    attributes: true,
    attributeFilter: ["lang"]
  });
})();
